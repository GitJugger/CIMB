Use [CIMBGatewayDB]
Go

ALTER TABLE tCor_UserDetails
ADD StaffNumber varchar(20);

ALTER TABLE tLog_Access
ADD Error_Msg varchar(20);

ALTER TABLE tLog_Access
ADD Error_Desc varchar(150);


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[MenuSetup](
	[MenuSetupId] [int] IDENTITY(1,1) NOT NULL,
	[MenuName] [varchar](50) NULL,
	[SeqNo] [int] NULL,
 CONSTRAINT [PK_MenuSetup] PRIMARY KEY CLUSTERED 
(
	[MenuSetupId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[PageSetup]    Script Date: 04-10-2024 18:03:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PageSetup](
	[PageSetupId] [int] IDENTITY(1,1) NOT NULL,
	[MenuSetupId] [int] NOT NULL,
	[PageName] [varchar](250) NOT NULL,
	[UrlPath] [varchar](200) NULL,
	[SeqNo] [int] NULL,
 CONSTRAINT [PK_PageSetup] PRIMARY KEY CLUSTERED 
(
	[PageSetupId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[RoleRights]    Script Date: 04-10-2024 18:03:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RoleRights](
	[Role_Rights_Id] [int] IDENTITY(1,1) NOT NULL,
	[Role_Name] [varchar](50) NOT NULL,
	[Menu_Name] [varchar](50) NOT NULL,
	[Page_Name] [varchar](250) NOT NULL,
	[Rights] [bit] NULL,
 CONSTRAINT [PK_RoleRights] PRIMARY KEY CLUSTERED 
(
	[Role_Rights_Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[RoleRights] ADD  CONSTRAINT [DF_RoleRights_Rights]  DEFAULT ((0)) FOR [Rights]
GO

ALTER TABLE [dbo].[PageSetup]  WITH CHECK ADD  CONSTRAINT [FK_PageSetup_MenuSetup] FOREIGN KEY([MenuSetupId])
REFERENCES [dbo].[MenuSetup] ([MenuSetupId])
GO

ALTER TABLE [dbo].[PageSetup] CHECK CONSTRAINT [FK_PageSetup_MenuSetup]
GO