USE [CIMBGatewayDB]
GO

/****** Object:  StoredProcedure [dbo].[fin_AuditTrail]    Script Date: 15-10-2024 15:45:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[fin_AuditTrail]  
	-- Add the parameters for the stored procedure here

	@in_FromDt VARCHAR(14),  
	@in_ToDt VARCHAR(14), 
	@in_UserId VARCHAR(14),  
	@in_UserName VARCHAR(20),
	@in_User VARCHAR(2)
	 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   
	SELECT 
        Date_Time,
        --(SELECT User_Name FROM tCor_UserDetails WHERE User_Id = Modify_By) AS Performed_By,
		Performed_By=CASE WHEN a.Flag_Type = 'O' THEN (SELECT Org_Name FROM ORG_MASTER WHERE Org_Id = a.Org_Id)   
  WHEN a.Flag_Type = 'U' THEN (SELECT User_Name FROM tCor_UserDetails WHERE User_Id = b.User_Id) END,
        Trans_Field,
        a.User_Id,
        Old_Data,
        New_Data,
		b.User_Name
    FROM 
        tCor_ModifyLogs a
		left join tCor_UserDetails b on b.User_Id=a.User_Id
    WHERE  Trans_Module in ('Modify Organisation','Modify User')
        AND 
        (
            (Isnull(@in_FromDt,'') =''  OR Isnull(@in_ToDt,'') ='') 
            OR (CONVERT(DATE, Date_Time) BETWEEN @in_FromDt AND @in_ToDt) 
        )
        AND 
        (
            Isnull(@in_UserName,'') = '' 
            OR b.User_Name = @in_UserName 
        )
		AND 
        (
            Isnull(@in_UserId,'') = '' 
            OR  a.User_Id = @in_UserId 
        )
    ORDER BY 
        Date_Time DESC;

END
GO

/****** Object:  StoredProcedure [dbo].[fin_GetMenu]    Script Date: 15-10-2024 15:45:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================


CREATE PROCEDURE [dbo].[fin_GetMenu]  
	-- Add the parameters for the stored procedure here

	
	 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   
SELECT MenuName, PageName, ROW_NUMBER() OVER (ORDER BY MenuName) as RightsId,0 as Rights 
FROM PageSetup AS PS 
INNER JOIN MenuSetup AS MS ON MS.MenuSetupId = PS.MenuSetupId 
order by MS.SeqNo,PS.SeqNo

END
GO

/****** Object:  StoredProcedure [dbo].[fin_GetRoleRights]    Script Date: 15-10-2024 15:45:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[fin_GetRoleRights]  
	-- Add the parameters for the stored procedure here

	@in_RoleName VARCHAR(20) 
	
	 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   
	SELECT Menu_Name as MenuName, Page_Name as PageName,c.UrlPath, Role_Rights_Id as RightsId,Rights 
	FROM RoleRights a
	join MenuSetup b on b.MenuName=a.Menu_Name
	join PageSetup c on c.PageName=a.Page_Name and b.MenuSetupId=c.MenuSetupId
	WHERE Role_Name =@in_RoleName
	order by b.seqNo

END
GO

/****** Object:  StoredProcedure [dbo].[fin_GetRoleRightsAll]    Script Date: 15-10-2024 15:45:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[fin_GetRoleRightsAll]  
	-- Add the parameters for the stored procedure here

	@in_menuName varchar(250)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

IF @in_menuName ='ALL'

BEGIN
   
	Select a.* from
(
SELECT 
    Menu_Name,
    Page_Name,
    MAX(CASE WHEN Role_Name = 'BU' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS BU,
    MAX(CASE WHEN Role_Name = 'BA' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS BA,
    MAX(CASE WHEN Role_Name = 'BS' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS BS,
	MAX(CASE WHEN Role_Name = 'BD' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS BD,
	MAX(CASE WHEN Role_Name = 'BO' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS BO,
	MAX(CASE WHEN Role_Name = 'CA' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS CA,
	MAX(CASE WHEN Role_Name = 'SA' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS SA,
	MAX(CASE WHEN Role_Name = 'IU' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS IU,
	MAX(CASE WHEN Role_Name = 'RD' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS RD,
	MAX(CASE WHEN Role_Name = 'U' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS U,
	MAX(CASE WHEN Role_Name = 'R' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS R,
	MAX(CASE WHEN Role_Name = 'A' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS A,
	MAX(CASE WHEN Role_Name = 'I' THEN CASE  WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS I
FROM 
    RoleRights a
	
GROUP BY 
    Menu_Name, 
    Page_Name


) a 
join MenuSetup b on b.MenuName=a.Menu_Name
order by b.seqNo

END

ELSE

BEGIN

	Select a.* from
(
SELECT 
    Menu_Name,
    Page_Name,
    MAX(CASE WHEN Role_Name = 'BU' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS BU,
    MAX(CASE WHEN Role_Name = 'BA' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS BA,
    MAX(CASE WHEN Role_Name = 'BS' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS BS,
	MAX(CASE WHEN Role_Name = 'BD' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS BD,
	MAX(CASE WHEN Role_Name = 'BO' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS BO,
	MAX(CASE WHEN Role_Name = 'CA' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS CA,
	MAX(CASE WHEN Role_Name = 'SA' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS SA,
	MAX(CASE WHEN Role_Name = 'IU' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS IU,
	MAX(CASE WHEN Role_Name = 'RD' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS RD,
	MAX(CASE WHEN Role_Name = 'U' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS U,
	MAX(CASE WHEN Role_Name = 'R' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS R,
	MAX(CASE WHEN Role_Name = 'A' THEN CASE WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS A,
	MAX(CASE WHEN Role_Name = 'I' THEN CASE  WHEN Rights = 1 THEN 1 ELSE 0 END ELSE 0 END) AS I
FROM 
    RoleRights a
	
GROUP BY 
    Menu_Name, 
    Page_Name


) a 
join MenuSetup b on b.MenuName=a.Menu_Name
Where b.MenuName=@in_menuName


END

END
GO

/****** Object:  StoredProcedure [dbo].[fin_UserListing]    Script Date: 15-10-2024 15:45:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[fin_UserListing]  
	-- Add the parameters for the stored procedure here

	@in_FromDt VARCHAR(14),  
	@in_ToDt VARCHAR(14), 
	@in_UserId VARCHAR(14),  
	@in_UserName VARCHAR(20),
	@in_StaffNumber VARCHAR(20)
	 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   
	WITH MatchedRecords AS (
    SELECT 
        a.User_Login,User_Name,StaffNumber
		,User_Flag 
		,User_Status = CASE 
		WHEN User_Status='A' THEN 'Active'
		WHEN User_Status='C' THEN 'InActive'
		WHEN User_Status='D' THEN 'Deleted'
		ELSE 'InActive'
		END
		,a.User_CreatedDt, 
        b.User_LoginDt, 
        ROW_NUMBER() OVER (PARTITION BY a.user_id ORDER BY b.User_LoginDt DESC) AS RowNum
    FROM tCor_UserDetails a
    INNER JOIN tLog_Access b ON b.User_Login=a.user_id
)
SELECT *
FROM MatchedRecords
	WHERE RowNum = 1
        AND 
        (
            (Isnull(@in_FromDt,'') =''  OR Isnull(@in_ToDt,'') ='') 
            OR (CONVERT(DATE, User_CreatedDt) BETWEEN @in_FromDt AND @in_ToDt) 
        )
        AND 
        (
            Isnull(@in_UserName,'') = '' 
            OR User_Name like  '%' + @in_UserName + '%'
        )
		AND 
        (
            Isnull(@in_UserId,'') = '' 
            OR  User_Login like '%' + @in_UserId + '%'
        )
		AND 
        (
            Isnull(@in_StaffNumber,'') = '' 
            OR  StaffNumber like '%' + @in_StaffNumber + '%'
        )
    ORDER BY 
        User_LoginDt DESC;

END
GO

/****** Object:  StoredProcedure [dbo].[fin_ViolationReport]    Script Date: 15-10-2024 15:45:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[fin_ViolationReport]  
	-- Add the parameters for the stored procedure here

	@in_FromDt VARCHAR(14),  
	@in_ToDt VARCHAR(14), 
	@in_UserId VARCHAR(14)
	
	 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   
	select Failed_AttemptDt,b.User_Login as User_Id,a.Error_Msg,a.Error_Desc from tLog_Access a
  inner join tCor_UserDetails b on b.User_Id=a.User_Login
  Where Failed_Attempt = 'Y' 
  AND 
        (
            (Isnull(@in_FromDt,'') =''  OR Isnull(@in_ToDt,'') ='') 
            OR (CONVERT(DATE, Failed_AttemptDt) BETWEEN @in_FromDt AND @in_ToDt) 
        )
        
		AND 
        (
            Isnull(@in_UserId,'') = '' 
            OR  b.User_Login like '%' + @in_UserId + '%'
        )
  ORDER BY Failed_AttemptDt DESC

END
GO


