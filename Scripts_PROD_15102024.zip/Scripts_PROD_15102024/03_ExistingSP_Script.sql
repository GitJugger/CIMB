USE [CIMBGatewayDB]
GO

/****** Object:  StoredProcedure [dbo].[pg_GetUserDetail]    Script Date: 15-10-2024 15:50:45 ******/
DROP PROCEDURE [dbo].[pg_GetUserDetail]
GO

/****** Object:  StoredProcedure [dbo].[pg_UserDetails]    Script Date: 15-10-2024 15:50:45 ******/
DROP PROCEDURE [dbo].[pg_UserDetails]
GO

/****** Object:  StoredProcedure [dbo].[pg_Userlogin_Failed]    Script Date: 15-10-2024 15:50:45 ******/
DROP PROCEDURE [dbo].[pg_Userlogin_Failed]
GO

/****** Object:  StoredProcedure [dbo].[pg_Userlogin_Failed]    Script Date: 15-10-2024 15:50:45 ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER ON
GO



---Author:- Eu Yean Lock t-melmax sdn bhd
---Date:- 18/10/2006
---Purpose:- to log the unsuccessful attempts


CREATE    PROC [dbo].[pg_Userlogin_Failed]

	@in_OrgId NUMERIC,
	@in_GroupId INT,
	@in_UserId NUMERIC,
	@in_UserIP VARCHAR(25),
	@in_ErrorMsg VARCHAR(150)
AS

BEGIN
	
	BEGIN

	IF LEN(@in_ErrorMsg) > 0

		BEGIN
			INSERT INTO [tLog_Access]([Org_Id], [Group_Id],[User_Login], [UserIP], [User_LoginDt], [User_LogoutDt], [Failed_Attempt], [Failed_AttemptDt],[Error_Msg],[Error_Desc])
			VALUES(@in_OrgId, @in_GroupId, @in_UserId, @in_UserIP,NULL,NULL, 'Y', GETDATE(),'LOGIN_FAILED',@in_ErrorMsg)

		END
	ELSE
		BEGIN
			INSERT INTO [tLog_Access]([Org_Id], [Group_Id],[User_Login], [UserIP], [User_LoginDt], [User_LogoutDt], [Failed_Attempt], [Failed_AttemptDt])
			VALUES(@in_OrgId, @in_GroupId, @in_UserId, @in_UserIP,NULL,NULL, 'Y', GETDATE())
		END
	END

END
GO

/****** Object:  StoredProcedure [dbo].[pg_UserDetails]    Script Date: 15-10-2024 15:50:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE     PROC [dbo].[pg_UserDetails]   
  @in_Action Varchar(10),    
  @in_UserId Numeric,    
  @in_OrgId Numeric,    
  @in_UserLogin VarChar(14),    
  @in_UserName VarChar(20),    
  @in_Password VarChar(24),    
  @in_ExpiryDt VarChar(10),    
  @in_ChangeUnit Varchar(1),    
  @in_ChangePeriod Integer,    
  @in_AuthCode Varchar(14),    
  @in_UserType VarChar(3),    
  @in_CreatedBy Numeric,    
  @in_UserStatus VarChar(1),  
 @in_Approved INT,  
 @in_AuthLimit MONEY,  
 @in_Display INT,  
 @in_Reset CHAR(1) = 'N',  
 @in_ReceiveEmail bit = 0,  
 @in_Email as varchar(50) = '',
 @in_StaffNumber as varchar(20) = '',
 @out_UserId NUMERIC OUTPUT  
  
AS    
  DECLARE @User_Id NUMERIC  
 DECLARE @User_PassExpiryDt DATETIME  
BEGIN    
  --Get User Password Expiry Date - Start  
 IF @in_ChangeUnit = 'D' --Day  
  BEGIN  
  SET @User_PassExpiryDt = DATEADD(DAY,@in_ChangePeriod,GETDATE())  
  END   
 ELSE IF @in_ChangeUnit = 'M' --Month  
  BEGIN  
  SET @User_PassExpiryDt = DATEADD(MONTH,@in_ChangePeriod,GETDATE())  
  END   
 ELSE IF @in_ChangeUnit = 'Y' --Year  
 BEGIN  
  SET @User_PassExpiryDt = DATEADD(YEAR,@in_ChangePeriod,GETDATE())  
  END   
  --Get User Password Expiry Date - Stop  
   
  IF @in_Action = 'ADD'    
  BEGIN    
    IF @in_UserType = 'EO'  
  BEGIN  
   INSERT INTO [tCor_UserDetails] (Org_Id,User_Login,User_Name,User_Password,User_Expiry,    
      User_Period,User_Unit,User_AuthCode,User_AuthChange,User_AuthLock,User_PassChange,  
    User_PassLock,User_Flag,User_CreatedDt,User_Status,User_CreatedBy,User_CreateDt,  
    User_PassExpiryDt,User_Approved,User_Limit,User_FileDisplay,IsReceiveEmail,IsOnline,StaffNumber)    
       
   VALUES (@in_OrgId,@in_UserLogin,@in_UserName,@in_Password,  
    Convert(DateTime,@in_ExpiryDt,103),@in_ChangePeriod,  
    @in_ChangeUnit,@in_AuthCode,'Y','Y','Y','Y','SA',GETDATE(),'C',@in_CreatedBy,  
    GETDATE(),@User_PassExpiryDt,@in_Approved,@in_AuthLimit,@in_Display,@in_ReceiveEmail,0,@in_StaffNumber)  
  END  
  ELSE  
  BEGIN  
	IF @in_UserType <> 'BD'
	BEGIN
		IF @in_AuthCode = 'N'  
			INSERT INTO [tCor_UserDetails] (Org_Id,User_Login,User_Name,User_Password,User_Expiry,    
			User_Period,User_Unit,User_AuthCode,User_AuthChange,User_AuthLock,User_PassChange,  
			User_PassLock,User_Flag,User_CreatedDt,User_Status,User_CreatedBy,User_CreateDt,  
			User_PassExpiryDt,User_Approved,User_Limit,User_FileDisplay,IsOnline,StaffNumber)    

			VALUES (@in_OrgId,@in_UserLogin,@in_UserName,@in_Password,  
			Convert(DateTime,@in_ExpiryDt,103),@in_ChangePeriod,  
			@in_ChangeUnit,@in_AuthCode,'N','N','Y','N',@in_UserType,GETDATE(),@in_UserStatus,@in_CreatedBy,  
			GETDATE(),@User_PassExpiryDt,@in_Approved,@in_AuthLimit,@in_Display,0,@in_StaffNumber)  
		ELSE  

			INSERT INTO [tCor_UserDetails] (Org_Id,User_Login,User_Name,User_Password,User_Expiry,    
			User_Period,User_Unit,User_AuthCode,User_AuthChange,User_AuthLock,User_PassChange,  
			User_PassLock,User_Flag,User_CreatedDt,User_Status,User_CreatedBy,User_CreateDt,  
			User_PassExpiryDt,User_Approved,User_Limit,User_FileDisplay,IsReceiveEmail,IsOnline,StaffNumber)    

			VALUES (@in_OrgId,@in_UserLogin,@in_UserName,@in_Password,  
			Convert(DateTime,@in_ExpiryDt,103),@in_ChangePeriod,  
			@in_ChangeUnit,@in_AuthCode,'Y','N','Y','N',@in_UserType,GETDATE(),@in_UserStatus,@in_CreatedBy,  
			GETDATE(),@User_PassExpiryDt,@in_Approved,@in_AuthLimit,@in_Display,@in_ReceiveEmail,0,@in_StaffNumber)  
	END  
	ELSE
	BEGIN
		INSERT INTO [tCor_UserDetails] (Org_Id,User_Login,User_Name,User_Password,User_Expiry,    
		User_Period,User_Unit,User_AuthCode,User_AuthChange,User_AuthLock,User_PassChange,  
		User_PassLock,User_Flag,User_CreatedDt,User_Status,User_CreatedBy,User_CreateDt,  
		User_PassExpiryDt,User_Approved,User_Limit,User_FileDisplay, User_Email,IsOnline,StaffNumber)    

		VALUES (@in_OrgId,@in_UserLogin,@in_UserName,@in_Password,  
		Convert(DateTime,@in_ExpiryDt,103),@in_ChangePeriod,  
		@in_ChangeUnit,@in_AuthCode,'N','N','Y','N',@in_UserType,GETDATE(),@in_UserStatus,@in_CreatedBy,  
		GETDATE(),@User_PassExpiryDt,@in_Approved,@in_AuthLimit,@in_Display, @in_Email,0,@in_StaffNumber) 
	END
  END
  SET @User_Id = @@IDENTITY  
  SET @out_UserId = @User_Id  
  RETURN @out_UserId  
    
    --Update Password History   
    INSERT INTO [tCor_PasswordHistory] (User_Id,Type,User_Password) VALUES(@User_Id,'PASS',@in_Password)  
    --Update Auth Code History   
    INSERT INTO [tCor_PasswordHistory] (User_Id,Type,User_Password) VALUES(@User_Id,'AUTH',@in_AuthCode)  
  
  END    
  ELSE IF @in_Action = 'UPDATE'    
  BEGIN    
    -- If Authorizer  
  IF @in_UserType = 'A'  
  BEGIN  
   -- update user details  
   UPDATE [tCor_UserDetails] SET User_Name = @in_UserName,User_Expiry = Convert(DATETIME,@in_ExpiryDt,103),User_Flag =  @in_UserType,    
     User_Period = @in_ChangePeriod,User_Unit = @in_ChangeUnit,User_Status = @in_UserStatus,User_ModifiedBy = @in_CreatedBy,  
   User_ModifyDt = GETDATE(),User_PassExpiryDt = @User_PassExpiryDt,User_Limit = @in_AuthLimit,User_Approved = @in_Approved,User_FileDisplay = @in_Display,StaffNumber=@in_StaffNumber   
   WHERE User_Id = @in_UserId  
  END  
  ELSE IF  @in_UserType = 'R'  
  BEGIN  
   -- update user details  
   UPDATE [tCor_UserDetails] SET User_Name = @in_UserName,User_Expiry = Convert(DATETIME,@in_ExpiryDt,103),User_Flag =  @in_UserType,    
     User_Period = @in_ChangePeriod,User_Unit = @in_ChangeUnit,User_Status = @in_UserStatus,User_ModifiedBy = @in_CreatedBy,  
   User_ModifyDt = GETDATE(),User_PassExpiryDt = @User_PassExpiryDt,User_Approved = @in_Approved ,User_FileDisplay = @in_Display,StaffNumber=@in_StaffNumber   
   WHERE User_Id = @in_UserId  
  END  
  ELSE  
  BEGIN  
   -- update user details  
   UPDATE [tCor_UserDetails] SET User_Name = @in_UserName,User_Expiry = Convert(DATETIME,@in_ExpiryDt,103),User_Flag =  @in_UserType,    
     User_Period = @in_ChangePeriod,User_Unit = @in_ChangeUnit,User_Status = @in_UserStatus,User_ModifiedBy = @in_CreatedBy,  
   User_ModifyDt = GETDATE(),User_PassExpiryDt = @User_PassExpiryDt,User_Approved = @in_Approved, IsReceiveEmail = @in_ReceiveEmail,
   User_Email = @in_Email,StaffNumber=@in_StaffNumber
   WHERE User_Id = @in_UserId  
  
   -- if Sys Admin or Sys Auth and status is active  
   IF (@in_UserType = 'CA' OR @in_UserType = 'SA') AND @in_UserStatus = 'A'  
   BEGIN  
    -- if password is locked, reset status  
    UPDATE tCor_UserDetails SET User_PassLock = 'N' WHERE User_PassLock = 'Y' AND User_Id = @in_UserId  
    -- if auth code is locked, reset status  
    UPDATE tCor_UserDetails SET User_AuthLock = 'N' WHERE User_AuthLock = 'Y' AND User_Id = @in_UserId  
  
    --reset sys admin/ sys auth - start  
    DECLARE @UserLogin VARCHAR(15)  
    SET @UserLogin = (SELECT User_Login FROM tCor_UserDetails WHERE User_Id = @in_UserId)  
    IF @in_Reset = 'Y'  
    BEGIN  
     -- Update New User Login,Password & Auth Code  
     UPDATE tCor_UserDetails SET User_Login = @in_UserLogin, User_PassLock = 'Y',User_AuthLock = 'Y',User_Password = @in_Password,  
     User_PassChange = 'Y',User_AuthChange = 'Y',User_AuthCode = @in_AuthCode,User_Status = 'C'   
     --WHERE User_Login <> @in_UserLogin AND User_Id = @in_UserId  
     WHERE User_Id = @in_UserId  
  
     -- Track Changes  
     INSERT INTO tUserId_Change (User_Id,Old_Login,New_Login,Date_Changed)  
      VALUES(@in_UserId,@UserLogin,@in_UserLogin,GETDATE())  
    END  
    --reset sys admin/ sys auth - stop   
   END  
  END  
  SET @out_UserId = @in_UserId  
  RETURN @out_UserId  
  END   
END  
GO

/****** Object:  StoredProcedure [dbo].[pg_GetUserDetail]    Script Date: 15-10-2024 15:50:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE  PROC [dbo].[pg_GetUserDetail]  
  @in_UserId NUMERIC    
AS    
BEGIN    
 SELECT Org_Id AS UOrgId,User_Login As ULogin,User_Name As UName,User_Password As UPwd,User_PassExpiryDt As UPassExpiryDt,    
  User_Expiry As UExpiry,User_Period As UPeriod,User_Unit As UUnit,User_AuthCode As UAuthCode,User_PassLock As ULock,  
 User_AuthChange As UAChange,User_AuthLock As UALock,User_Limit AS ULimit,User_Flag As UType,User_Status As UStatus,  
 User_FileDisplay AS UDisplay,User_CreatedDt as UCreateDt,User_PassReset as UReset,User_PassResetDt AS UResetDt,  
 User_Approved AS UAppr,IsReceiveEmail, User_email,StaffNumber FROM tCor_UserDetails WHERE User_Id = @in_UserId    
END
GO


